# File: backend/main.py
# To run this backend locally:
# 1. Install/update dependencies:
#    pip install "fastapi[all]" pandas scikit-learn python-multipart scipy
# 2. Save this code as main.py in your `backend` folder.
# 3. Run the server:
#    uvicorn main:app --reload

from fastapi import FastAPI, File, UploadFile, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
from typing import List, Dict, Any, Optional
import pandas as pd
from io import StringIO
from starlette.responses import StreamingResponse
import numpy as np

# Import scikit-learn transformers
from sklearn.impute import SimpleImputer, KNNImputer
from sklearn.preprocessing import StandardScaler, MinMaxScaler, LabelEncoder, OneHotEncoder
from sklearn.experimental import enable_iterative_imputer
from sklearn.impute import IterativeImputer

# Initialize the FastAPI app
app = FastAPI(
    title="DataSpark AI Preprocessing API (v3)",
    description="An intelligent API for analyzing and cleaning CSV data with heuristic-based suggestions.",
    version="3.0.0",
)

# --- CORS Configuration ---
origins = [
    "http://localhost",
    "http://localhost:3000",
]

app.add_middleware(
    CORSMiddleware,
    allow_origins=origins,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# --- Pydantic Models ---
class ColumnAnalysis(BaseModel):
    column_name: str
    data_type: str
    missing_values: int
    missing_percentage: float
    unique_values: int
    suggestions: List[str] = []
    recommended_action: Optional[str] = None
    is_problematic: bool = False

class AnalysisResponse(BaseModel):
    filename: str
    row_count: int
    column_count: int
    column_analysis: List[ColumnAnalysis]

class Action(BaseModel):
    column: str
    action: str
    value: Optional[Any] = None

class ProcessRequest(BaseModel):
    data: List[Dict[str, Any]]
    actions: List[Action]


# --- Helper Functions for Analysis ---
def analyze_column(df: pd.DataFrame, column_name: str) -> ColumnAnalysis:
    """Analyzes a single column and generates a comprehensive list of cleaning suggestions."""
    col = df[column_name]
    data_type = str(col.dtype)
    missing_values = int(col.isnull().sum())
    total_rows = len(df)
    missing_percentage = round((missing_values / total_rows) * 100, 2) if total_rows > 0 else 0
    unique_values = int(col.nunique())
    
    suggestions = ["drop_column"]
    recommended_action = None
    is_problematic = False

    # --- Problem Detection ---
    if missing_values > 0:
        is_problematic = True
    
    # --- Missing Value Suggestions ---
    if is_problematic:
        suggestions.append("drop_missing_rows")
        if np.issubdtype(col.dtype, np.number):
            # Recommend median for skewed data, mean otherwise
            if abs(col.skew()) > 1:
                recommended_action = "impute_median"
                suggestions.extend(["impute_median", "impute_mean", "impute_knn", "impute_iterative"])
            else:
                recommended_action = "impute_mean"
                suggestions.extend(["impute_mean", "impute_median", "impute_knn", "impute_iterative"])
        else: # For object types
             recommended_action = "impute_mode"
        suggestions.append("impute_mode")

    # --- Type-Specific Suggestions ---
    if data_type == 'object':
        suggestions.extend(["to_lowercase", "to_uppercase", "trim_whitespace", "remove_special_characters"])
        if 1 < unique_values <= 50:
            suggestions.extend(["one_hot_encode", "label_encode"])
            if not recommended_action: recommended_action = "one_hot_encode"
        try:
            if pd.to_numeric(col, errors='coerce').notna().sum() / col.notna().sum() > 0.8:
                suggestions.append("convert_to_numeric")
                if not recommended_action: recommended_action = "convert_to_numeric"
        except Exception: pass
        try:
            if pd.to_datetime(col, errors='coerce').notna().sum() / col.notna().sum() > 0.8:
                suggestions.append("convert_to_datetime")
                if not recommended_action: recommended_action = "convert_to_datetime"
        except Exception: pass
    
    elif np.issubdtype(col.dtype, np.number):
        is_scalable = True
        if col.nunique() < 20: is_scalable = False
        if is_scalable and (col.dropna() % 1 == 0).all():
            if col.min() > 1900 and col.max() < 2100: is_scalable = False
            unique_sorted = np.sort(col.dropna().unique())
            if len(unique_sorted) > 2 and np.all(np.diff(unique_sorted) == 1): is_scalable = False
        
        if is_scalable:
            suggestions.extend(["scale_standard", "scale_minmax"])
        
        if col.min() >= 0 and col.skew() > 1.5:
            suggestions.append("transform_log")
            if not recommended_action: recommended_action = "transform_log"

        q1, q3 = col.quantile(0.25), col.quantile(0.75)
        iqr = q3 - q1
        outliers = col[(col < (q1 - 1.5 * iqr)) | (col > (q3 + 1.5 * iqr))]
        if not outliers.empty:
            is_problematic = True
            suggestions.append("handle_outliers_iqr")
            if not recommended_action: recommended_action = "handle_outliers_iqr"

    elif 'datetime' in data_type:
        suggestions.extend(["extract_year", "extract_month", "extract_day", "extract_day_of_week"])

    return ColumnAnalysis(
        column_name=column_name, 
        data_type=data_type, 
        missing_values=missing_values, 
        missing_percentage=missing_percentage, 
        unique_values=unique_values, 
        suggestions=list(dict.fromkeys(suggestions)),
        recommended_action=recommended_action,
        is_problematic=is_problematic
    )

# --- API Endpoints ---
@app.get("/")
def read_root():
    return {"message": "Welcome to the DataSpark AI Preprocessing API (v3)"}

@app.post("/analyze", response_model=AnalysisResponse)
async def analyze_csv(file: UploadFile = File(...)):
    try:
        contents = await file.read()
        df = pd.read_csv(StringIO(contents.decode('utf-8')))
    except Exception as e:
        raise HTTPException(status_code=400, detail=f"Error processing CSV file: {e}")
    
    row_count, col_count = df.shape
    analysis_results = [analyze_column(df, col) for col in df.columns]
    
    return AnalysisResponse(
        filename=file.filename, 
        row_count=row_count, 
        column_count=col_count, 
        column_analysis=analysis_results
    )

@app.post("/process")
async def process_data(request: ProcessRequest):
    try:
        df = pd.DataFrame(request.data)
    except Exception as e:
        raise HTTPException(status_code=400, detail=f"Could not load data into DataFrame: {e}")

    for action in request.actions:
        col_name = action.column
        if col_name not in df.columns: continue
        
        try:
            if action.action == 'drop_column':
                df.drop(columns=[col_name], inplace=True)
                continue
            elif action.action == 'drop_missing_rows':
                df.dropna(subset=[col_name], inplace=True)
            elif action.action in ['impute_mean', 'impute_median', 'impute_mode']:
                strategy_map = {'impute_mean': 'mean', 'impute_median': 'median', 'impute_mode': 'most_frequent'}
                imputer = SimpleImputer(strategy=strategy_map[action.action])
                if strategy_map[action.action] in ['mean', 'median']:
                    df[col_name] = pd.to_numeric(df[col_name], errors='coerce')
                df[[col_name]] = imputer.fit_transform(df[[col_name]])
            elif action.action == 'impute_knn':
                imputer = KNNImputer()
                df[col_name] = pd.to_numeric(df[col_name], errors='coerce')
                df[[col_name]] = imputer.fit_transform(df[[col_name]])
            elif action.action == 'impute_iterative':
                imputer = IterativeImputer(max_iter=10, random_state=0)
                df[col_name] = pd.to_numeric(df[col_name], errors='coerce')
                df[[col_name]] = imputer.fit_transform(df[[col_name]])
            elif action.action == 'to_lowercase': df[col_name] = df[col_name].astype(str).str.lower()
            elif action.action == 'to_uppercase': df[col_name] = df[col_name].astype(str).str.upper()
            elif action.action == 'trim_whitespace': df[col_name] = df[col_name].astype(str).str.strip()
            elif action.action == 'remove_special_characters': df[col_name] = df[col_name].astype(str).str.replace(r'[^A-Za-z0-9\s]+', '', regex=True)
            elif action.action == 'label_encode': df[col_name] = LabelEncoder().fit_transform(df[col_name].astype(str))
            elif action.action == 'one_hot_encode':
                encoder = OneHotEncoder(handle_unknown='ignore', sparse_output=False)
                encoded_cols = encoder.fit_transform(df[[col_name]])
                encoded_df = pd.DataFrame(encoded_cols, columns=encoder.get_feature_names_out([col_name]))
                df = df.join(encoded_df)
                df.drop(columns=[col_name], inplace=True)
            elif action.action == 'scale_standard': df[[col_name]] = StandardScaler().fit_transform(df[[col_name]])
            elif action.action == 'scale_minmax': df[[col_name]] = MinMaxScaler().fit_transform(df[[col_name]])
            elif action.action == 'transform_log': df[col_name] = np.log1p(df[col_name])
            elif action.action == 'handle_outliers_iqr':
                if np.issubdtype(df[col_name].dtype, np.number):
                    q1, q3 = df[col_name].quantile(0.25), df[col_name].quantile(0.75)
                    iqr = q3 - q1
                    lower, upper = q1 - 1.5 * iqr, q3 + 1.5 * iqr
                    df[col_name] = df[col_name].clip(lower=lower, upper=upper)
            elif 'extract_' in action.action:
                dt_col = pd.to_datetime(df[col_name], errors='coerce')
                part = action.action.split('_')[-1]
                if part == 'year': df[f'{col_name}_year'] = dt_col.dt.year
                elif part == 'month': df[f'{col_name}_month'] = dt_col.dt.month
                elif part == 'day': df[f'{col_name}_day'] = dt_col.dt.day
                elif part == 'day_of_week': df[f'{col_name}_day_of_week'] = dt_col.dt.dayofweek
        except Exception as e:
            print(f"Could not apply action '{action.action}' on column '{col_name}': {e}")
            continue

    output = StringIO()
    df.to_csv(output, index=False)
    output.seek(0)
    
    return StreamingResponse(
        output, 
        media_type="text/csv", 
        headers={"Content-Disposition": f"attachment; filename=cleaned_data.csv"}
    )